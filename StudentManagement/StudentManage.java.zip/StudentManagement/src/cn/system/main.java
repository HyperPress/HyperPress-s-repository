package cn.system;

public class main {
    public static void main(String[] args) {
        new LoginFrame();
    }
}
